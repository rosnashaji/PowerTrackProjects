/*
 * File:   can.h
 * Author: rosna
 *
 * Created on 2 July, 2026, 9:58 AM
 */

#ifndef CAN_H
#define CAN_H

#include <xc.h>
#include <stdint.h>

#define _XTAL_FREQ 20000000

/* CAN Operation Modes */

#define CAN_OP_MODE_NORMAL      0x00
#define CAN_OP_MODE_LOOPBACK    0x40
#define CAN_OP_MODE_CONFIG      0x80

#define CAN_SET_OPERATION_MODE_NO_WAIT(mode) \
{                                            \
    CANCON &= 0x1F;                          \
    CANCON |= (mode);                        \
}

void init_can(void);

void can_receive(uint16_t *msg_id,uint8_t *data,uint8_t *len);

#endif