/*
 * File:   ecu3_sensor.h
 * Author: rosna
 *
 * Created on 2 July, 2026, 9:59 AM
 */


#ifndef ECU3_SENSOR_H
#define ECU3_SENSOR_H

void receive_can_data(void);

#endif