/*
 * File:   ecu3_sensor.c
 * Author: rosna
 *
 * Created on 1 July, 2026, 9:59 AM
 */


#include <xc.h>
#include <stdint.h>

#include "clcd.h"
#include "can.h"
#include "msg_id.h"
#include "ecu3_sensor.h"

void receive_can_data(void)
{
    uint16_t msg_id;
    uint8_t rx_data[8];
    uint8_t len;

    can_receive(&msg_id, rx_data, &len);

    if(len == 0)
        return;

    switch(msg_id)
    {

        case RPM_MSG_ID:

            if(len == 4)
            {
                clcd_putch(rx_data[0], LINE2(0));
                clcd_putch(rx_data[1], LINE2(1));
                clcd_putch(rx_data[2], LINE2(2));
                clcd_putch(rx_data[3], LINE2(3));
            }

            break;


        case INDICATOR_MSG_ID:

            if(len == 1)
            {
                switch(rx_data[0])
                {
                    case 1:         /* LEFT */

                        clcd_print("L", LINE2(5));

                        RB0 = 1;
                        RB1 = 1;

                        RB6 = 0;
                        RB7 = 0;

                        break;

                    case 2:         /* RIGHT */

                        clcd_print("R", LINE2(5));

                        RB0 = 0;
                        RB1 = 0;

                        RB6 = 1;
                        RB7 = 1;

                        break;

                    case 3:         /* HAZARD */

                        clcd_print("H", LINE2(5));

                        RB0 = 1;
                        RB1 = 1;

                        RB6 = 1;
                        RB7 = 1;

                        break;

                    case 0:        /* OFF */

                        clcd_print("O", LINE2(5));

                        RB0 = 0;
                        RB1 = 0;

                        RB6 = 0;
                        RB7 = 0;

                        break;
                }
            }

            break;

       

        case SPEED_MSG_ID:

            if(len == 3)
            {
                clcd_putch(rx_data[0], LINE2(8));
                clcd_putch(rx_data[1], LINE2(9));
                clcd_putch(rx_data[2], LINE2(10));
            }
            
            break;

       

        case GEAR_MSG_ID:

            if(len == 1)
            {
                clcd_putch(rx_data[0], LINE2(12));
            }

            break;
    }
}