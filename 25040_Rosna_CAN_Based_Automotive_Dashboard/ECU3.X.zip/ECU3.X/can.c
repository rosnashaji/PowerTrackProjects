/*
 * File:   can.c
 * Author: rosna
 *
 * Created on 2 July, 2026, 9:58 AM
 */


#include <xc.h>
#include <stdint.h>
#include "can.h"

/* CAN Operation Modes */
typedef enum
{
    e_can_op_mode_normal = 0x00,
    e_can_op_mode_loop   = 0x40,
    e_can_op_mode_config = 0x80

} CanOpMode;

static uint16_t get_msg_id_std(void)
{
    uint16_t id;

    id = RXB0SIDH;
    id = id << 3;
    id |= (RXB0SIDL >> 5);

    return id;
}

void init_can(void)
{
    /* CAN TX -> RB2 */
    TRISB2 = 0;

    /* CAN RX -> RB3 */
    TRISB3 = 1;

    /* Enter Configuration Mode */
    CAN_SET_OPERATION_MODE_NO_WAIT(e_can_op_mode_config);

    while((CANSTAT & 0xE0) != e_can_op_mode_config);

    /* Legacy Mode */
    ECANCON = 0x00;

    /* CAN Bit Timing (20 MHz Crystal) */
    BRGCON1 = 0xE1;
    BRGCON2 = 0x1B;
    BRGCON3 = 0x03;
    /* Receive Buffer 0 */
    //RXB0CON = 0x00;
    RXB0CON = 0x60;      // RXM1:RXM0 = 11 -> Receive all valid messages

    /* Accept all Standard IDs */

    RXM0SIDH = 0x00;
    RXM0SIDL = 0x00;

    RXF0SIDH = 0x00;
    RXF0SIDL = 0x00;

    RXB0FUL = 0;
    RXB0IF = 0;

    /* Enter Normal Mode */

    CAN_SET_OPERATION_MODE_NO_WAIT(e_can_op_mode_normal);

    while((CANSTAT & 0xE0) != e_can_op_mode_normal);
}


void can_receive(uint16_t *msg_id, uint8_t *data, uint8_t *len)
{
    uint8_t i;

    if(!RXB0FUL)
    {
        *len = 0;
        return;
    }

    *msg_id = get_msg_id_std();

    *len = RXB0DLC & 0x0F;

    for(i = 0; i < *len; i++)
    {
        data[i] = *((uint8_t *)&RXB0D0 + i);
    }

    RXB0FUL = 0;
    RXB0IF = 0;
}
