/*
 * File:   main.c
 * Author: rosna
 *
 * Created on 2 July, 2026, 10:00 AM
 */

/*
 Name : Rosna Shaji
 Id : 25040B_014
 ECU3 - Display RPM,Indicator,Speed and Gear using CLCD
 Date :- 08-07-2026
 */

#include <xc.h>

#include "clcd.h"
#include "can.h"
#include "ecu3_sensor.h"
#include "msg_id.h"

void main(void)
{
    ADCON1 = 0x0F;

    init_clcd();
    init_can();

    /* LED Pins */
    TRISB0 = 0;
    TRISB1 = 0;
    TRISB6 = 0;
    TRISB7 = 0;

    PORTB = 0x00;

    /* Heading */
    clcd_print("RPM IND SPD GR", LINE1(0));

    while(1)
    {
        receive_can_data();
    }
}
