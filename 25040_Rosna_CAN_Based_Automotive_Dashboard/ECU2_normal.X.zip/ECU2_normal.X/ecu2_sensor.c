/*
 * File:   ecu2_sensor.c
 * Author: rosna
 *
 * Created on 1 July, 2026, 11:06 PM
 */


#include <xc.h>
#include <stdint.h>

#include "adc.h"
#include "digital_keypad.h"
#include "can.h"
#include "msg_id.h"
#include "ecu2_sensor.h"

#define _XTAL_FREQ 20000000

unsigned char mode = 0;


void get_rpm(void)
{
    unsigned short adc_val;
    unsigned short rpm;

    uint8_t tx_data[4];

    adc_val = read_adc(CHANNEL4);

    rpm = ((unsigned long)adc_val * 6000) / 1023;

    tx_data[0] = (rpm / 1000) + '0';
    tx_data[1] = ((rpm / 100) % 10) + '0';
    tx_data[2] = ((rpm / 10) % 10) + '0';
    tx_data[3] = (rpm % 10) + '0';

    can_transmit(RPM_MSG_ID, tx_data, 4);
   
    
}


void get_indicator(void)
{
    unsigned char key;
    uint8_t tx_data[1];

    key = read_digital_keypad(STATE_CHANGE);

    switch(key)
    {
        case SWITCH1:
            mode = 1;      // LEFT
            break;

        case SWITCH2:
            mode = 2;      // RIGHT
            break;

        case SWITCH3:
            mode = 3;      // HAZARD
            break;

        case SWITCH4:
            mode = 0;      // OFF
            break;
    }

    tx_data[0] = mode;

    can_transmit(INDICATOR_MSG_ID, tx_data, 1);
    
    
}

