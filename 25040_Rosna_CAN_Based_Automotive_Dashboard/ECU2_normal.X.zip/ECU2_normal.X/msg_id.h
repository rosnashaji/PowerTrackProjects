/*
 * File:   msg_id.h
 * Author: rosna
 *
 * Created on 1 July, 2026, 11:05 PM
 */


#ifndef MSG_ID_H
#define MSG_ID_H

#define GEAR_MSG_ID        0x100
#define SPEED_MSG_ID       0x101
#define RPM_MSG_ID         0x102
#define INDICATOR_MSG_ID   0x103

#endif