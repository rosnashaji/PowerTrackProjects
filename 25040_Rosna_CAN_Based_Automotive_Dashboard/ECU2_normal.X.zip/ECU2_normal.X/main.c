/*
 * File:   main.c
 * Author: rosna
 *
 * Created on 1 July, 2026, 11:06 PM
 */

/*
 Name : Rosna Shaji
 Id : 25040B_014
 ECU2 - RPM and Indicator using Potentiometer and digital keypad
 Date :- 08-07-2026
 */

#include <xc.h>

#include "adc.h"
#include "can.h"
#include "digital_keypad.h"
#include "ecu2_sensor.h"

void main(void)
{
    ADCON1 = 0x0F;

    init_adc();
    init_can();
    init_digital_keypad();

    while(1)
    {
        get_rpm();
        
        get_indicator();
     
    }
}
