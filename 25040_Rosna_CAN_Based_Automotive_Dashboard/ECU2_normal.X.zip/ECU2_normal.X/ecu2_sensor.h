/*
 * File:   ecu2_sensor.h
 * Author: rosna
 *
 * Created on 1 July, 2026, 11:06 PM
 */

#ifndef ECU2_SENSOR_H
#define ECU2_SENSOR_H

void get_rpm(void);
void get_indicator(void);

#endif