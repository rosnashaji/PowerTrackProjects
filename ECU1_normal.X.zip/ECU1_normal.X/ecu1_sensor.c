/*
 * File:   ecu1_sensor.c
 * Author: rosna
 *
 * Created on 1 July, 2026, 10:15 PM
 */


#include <xc.h>
#include <stdint.h>
#include "adc.h"
#include "can.h"
#include "ecu1_sensor.h"
#include "digital_keypad.h"
#include "msg_id.h"

unsigned char gear_pos = 0;

char gear[] = {'N','1','2','3','4','5','R'};


void get_gear(void)
{
    unsigned char key;
    uint8_t tx_data[1];

    key = read_digital_keypad(STATE_CHANGE);

    if(key == SWITCH1)
    {
        if(gear_pos < 6)
        {
            gear_pos++;
        }
    }
    else if(key == SWITCH2)
    {
        if(gear_pos > 0)
        {
            gear_pos--;
        }
    }

    tx_data[0] = gear[gear_pos];

    can_transmit(GEAR_MSG_ID, tx_data, 1);
   
}


void get_speed(void)
{
    unsigned short adc_val;
    unsigned char speed;

    uint8_t tx_data[3];

    adc_val = read_adc(CHANNEL4);

    speed = ((unsigned long)adc_val * 100) / 1023;

    if(gear[gear_pos] == 'N')
    {
        speed = 0;
    }

    tx_data[0] = (speed / 100) + '0';
    tx_data[1] = ((speed / 10) % 10) + '0';
    tx_data[2] = (speed % 10) + '0';

    can_transmit(SPEED_MSG_ID, tx_data, 3);
    
}