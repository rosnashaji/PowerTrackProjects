/*
 * File:   can.c
 * Author: rosna
 *
 * Created on 1 July, 2026, 10:15 PM
 */



#include <xc.h>
#include <stdint.h>
#include "can.h"

/* CAN Operation Modes */
typedef enum
{
    e_can_op_mode_normal = 0x00,
    e_can_op_mode_loop   = 0x40,
    e_can_op_mode_config = 0x80

} CanOpMode;

static void set_msg_id_std(uint16_t id)
{
    TXB0SIDH = (uint8_t)(id >> 3);
    TXB0SIDL = (uint8_t)((id & 0x07) << 5);

    TXB0SIDL &= ~(1 << 3);      // Standard Frame
    TXB0EIDH = 0x00;
    TXB0EIDL = 0x00;
}

void init_can(void)
{
    /* CAN Pins */
    TRISB2 = 0;          // TX
    TRISB3 = 1;          // RX

    /* Enter Configuration Mode */
    CAN_SET_OPERATION_MODE_NO_WAIT(e_can_op_mode_config);

    while((CANSTAT & 0xE0) != e_can_op_mode_config);

    /* CAN Mode */
    ECANCON = 0x00;

    /* CAN Bit Timing (20MHz Crystal, 125kbps) */
    BRGCON1 = 0xE1;
    BRGCON2 = 0x1B;
    BRGCON3 = 0x03;

    /* Disable Filters */
    RXFCON0 = 0x00;

    /* Receive Buffer */
    RXB0CON = 0x00;

    /* Enter Normal Mode */
    CAN_SET_OPERATION_MODE_NO_WAIT(e_can_op_mode_normal);

    while((CANSTAT & 0xE0) != e_can_op_mode_normal);
}

void can_transmit(uint16_t msg_id, const uint8_t *data, uint8_t len)
{
    uint8_t i;

    /* Wait until previous transmission is complete */
    while(TXB0REQ);

    /* Set Identifier */
    set_msg_id_std(msg_id);

    /* Data Length */
    TXB0DLC = len & 0x0F;

    /* Copy Data */
    for(i = 0; i < len; i++)
    {
        *((volatile uint8_t *)&TXB0D0 + i) = data[i];
    }

    /* Start Transmission */
    TXB0REQ = 1;
}