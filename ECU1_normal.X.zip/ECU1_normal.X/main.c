/*
 * File:   main.c
 * Author: rosna
 *
 * Created on 1 July, 2026, 10:15 PM
 */

/*
 Name : Rosna Shaji
 Id : 25040B_014
 ECU1 - Speed and Gear using Potentiometer and digital keypad
 Date :- 08-07-2026
 */


#include <xc.h>

#include "adc.h"
#include "can.h"
#include "digital_keypad.h"
#include "ecu1_sensor.h"
#include "msg_id.h"
    

void main(void)
{
    ADCON1 = 0x0F;

    init_adc();
    init_can();
    init_digital_keypad();


    while(1)
    {    
        get_gear();
        
        get_speed();
        
    }
}