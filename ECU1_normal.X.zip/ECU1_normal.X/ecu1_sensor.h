/*
 * File:   ecu1_sensor.h
 * Author: rosna
 *
 * Created on 1 July, 2026, 10:11 PM
 */


#ifndef ECU1_SENSOR_H
#define ECU1_SENSOR_H

#include <xc.h>

#define _XTAL_FREQ 20000000

// Share internal variables with main if required
extern char gear[];
extern unsigned char gear_pos;
extern unsigned char speed;


// Function declarations for isolated testing
void get_gear(void);
void get_speed(void);

#endif /* ECU1_SENSOR_H */
