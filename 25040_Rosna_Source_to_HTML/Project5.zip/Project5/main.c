/*
Name        : Rosna Shaji
Date        : 01-08-2026
Description : Project :- Source to HTML Converter

              Functionalities:
              1. Source File Parsing :- Reads the input C source file character by character and analyzes its contents.
              2. Syntax Highlighting :- Identifies different C language tokens and highlights them using HTML color formatting.
              3. Keyword Identification :- Classifies data type keywords and non-data type keywords with different colors.
              4. Preprocessor Detection :- Detects preprocessor directives such as #include and #define, and highlights them separately.
              5. Header File Recognition :- Identifies header files enclosed within < > and displays them with a separate color.
              6. Constant Detection :- Detects numeric constants, string literals and character constants, and highlights them appropriately.
              7. Comment Recognition :- Identifies both single-line (//) and multi-line comments and applies comment formatting.
              8. HTML Entity Conversion :- Converts special characters such as <, > and & into their corresponding HTML entities (&lt;, &gt; and &amp;) to ensure correct HTML rendering.
              9. Line Number Support :- Optionally displays line numbers in the generated HTML file using the -n command-line option.
             10. HTML File Generation :- Generates a syntax-highlighted HTML file that preserves the original source code formatting, indentation and line structure for viewing in a web browser.
*/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "parser.h"
#include "html.h"

int main(int argc, char *argv[])
{
    FILE *src, *dest;
    int line_enable = 0;

    if(argc != 3 && argc != 4)
    {
        printf("USAGE:\n");
        printf("./a.out <src_file.c> <output.html> <-n>\n");
        return 1;
    }

    if(argc == 4)
    {
        if(strcmp(argv[3], "-n") == 0)
            line_enable = 1;
        else
        {
            printf("Invalid option\n");
            return 1;
        }
    }

    src = fopen(argv[1], "r");

    if(src == NULL)
    {
        printf("Unable to open %s\n", argv[1]);
        return 1;
    }

    dest = fopen(argv[2], "w");

    if(dest == NULL)
    {
        printf("Unable to create %s\n", argv[2]);
        fclose(src);
        return 1;
    }

    html_start(dest);

    parse_file(src, dest, line_enable);

    html_end(dest);

    fclose(src);
    fclose(dest);

    printf("Conversion to HTML file done successfully\n");

    return 0;
}

