#ifndef PARSER_H
#define PARSER_H

#include <stdio.h>

void parse_file(FILE *src, FILE *dest, int line_enable);

#endif