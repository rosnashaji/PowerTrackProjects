#ifndef KEYWORDS_H
#define KEYWORDS_H

#define NOT_KEYWORD      0
#define DATA_KEYWORD     1
#define NONDATA_KEYWORD  2

int keyword_type(char *word);

#endif