#include <stdio.h>

#define SQUARE(num) (num * num)

int main()
{
    int num = 5;

    printf("Square of a given number is %d\n", SQUARE(num));

    // This is a comment

    /*
       Multi-line
       comment
    */

    char ch = 'A';

    return 0;
}


