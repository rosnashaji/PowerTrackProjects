#ifndef STYLE_H
#define STYLE_H

#define HTML_START \
"<html>\n"\
"<head>\n"\
"<title>Source To HTML</title>\n"\
"</head>\n"\
"<body bgcolor=\"black\" text=\"white\">\n"\
"<pre>\n"

#define HTML_END \
"</pre>\n"\
"</body>\n"\
"</html>\n"

#define DATA_KEYWORD_COLOR      "green"

#define NONDATA_KEYWORD_COLOR   "goldenrod"

#define COMMENT_COLOR           "blue"

#define PREPROCESSOR_COLOR      "purple"

#define HEADER_COLOR            "red"

#define STRING_COLOR            "magenta"

#define NUMBER_COLOR            "brown"

#define CHARACTER_COLOR         "firebrick"

#define NORMAL_COLOR            "white"

#endif