int main()
{
    printf("Hello World\n");

    int a = 10;

    float b = 12.5;

    char ch = 'A';

    char str[] = "Hello";

    int x = 0x1f;

    int x = 0b1010;

    int y=077;

    return 0;
}