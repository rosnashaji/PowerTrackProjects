int main()
{
    printf("Hello World\n");

    int a=10;

    float b=12.5;

    char ch='A';

    return 0;
}
